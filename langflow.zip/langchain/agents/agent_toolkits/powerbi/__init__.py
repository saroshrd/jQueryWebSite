"""Power BI agent."""
