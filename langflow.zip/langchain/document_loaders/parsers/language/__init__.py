from langchain.document_loaders.parsers.language.language_parser import LanguageParser

__all__ = ["LanguageParser"]
