"""
Demonstration Script: Deep Agents LLM Harness on Windows 11
Standalone Execution Sandbox (Zero Docker / Zero Podman).
"""

import sys
import time
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from windows_sandbox import WindowsStandaloneSandbox
from deep_agent_harness import DeepAgentWindowsHarness, create_windows_deep_agent

# Ensure UTF-8 output on Windows consoles
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

console = Console(highlight=False)

def run_standalone_sandbox_demo():
    console.print(Panel.fit(
        "[bold cyan]Part 1: Windows 11 Standalone Sandbox Kernel Limits Test[/bold cyan]\n"
        "[dim]Testing RAM isolation, Active Process cap, and Kill-on-Close via Windows NT Job Objects[/dim]",
        border_style="cyan"
    ))

    with WindowsStandaloneSandbox(max_memory_mb=128, default_timeout=5) as sbx:
        console.print(f"[green][OK][/green] Initialized Sandbox: [bold]{sbx.id}[/bold]")
        console.print(f"[green][OK][/green] Workspace Root: [bold]{sbx.workspace}[/bold]")

        # Test normal script
        normal_code = """
import sys, math
print("Standalone Windows 11 Sandbox Active!")
print(f"Python: {sys.version.split()[0]} | Platform: {sys.platform}")
print(f"Calculated Pi approx: {math.pi:.6f}")
"""
        console.print("\n[yellow]Executing benign Python workload...[/yellow]")
        res = sbx.run_code(normal_code)
        console.print(f"Status: [{'green' if res.success else 'red'}]{res.summary()}[/]")

        # Test memory limit enforcement
        console.print("\n[yellow]Testing Kernel Memory Limit Enforcement (allocating beyond 128MB limit)...[/yellow]")
        oom_code = """
# Attempt to allocate 300MB
chunk = bytearray(300 * 1024 * 1024)
print("Allocated successfully!")
"""
        res_oom = sbx.run_code(oom_code)
        if not res_oom.success and "MemoryError" in res_oom.output:
            console.print("[bold green][OK] SUCCESS:[/] Windows Kernel intercepted memory exhaustion and triggered MemoryError!")
        else:
            console.print(f"[bold yellow]Result:[/] {res_oom.output}")

def run_loop_engineering_harness_demo():
    console.print(Panel.fit(
        "[bold magenta]Part 2: Deep Agent Iterative Loop Engineering Harness[/bold magenta]\n"
        "[dim]LangGraph autonomous self-repair loop with Windows 11 Standalone Sandbox[/dim]",
        border_style="magenta"
    ))

    task = "Write a function `fibonacci(n: int) -> int` that computes the nth Fibonacci number (0-indexed, where fib(0)=0, fib(1)=1, fib(2)=1). Handle n < 0 by raising ValueError."
    
    test_suite = """
assert fibonacci(0) == 0, "fib(0) should be 0"
assert fibonacci(1) == 1, "fib(1) should be 1"
assert fibonacci(2) == 1, "fib(2) should be 1"
assert fibonacci(7) == 13, "fib(7) should be 13"
assert fibonacci(10) == 55, "fib(10) should be 55"
try:
    fibonacci(-1)
    assert False, "Should raise ValueError for negative n"
except ValueError:
    pass
print("ALL FIBONACCI TESTS VALIDATED IN WINDOWS STANDALONE SANDBOX!")
"""

    console.print(f"[cyan]Task:[/] {task}\n")
    console.print("[yellow]Starting Deep Agent Harness with local Ollama 'gemma3:1b'...[/yellow]")

    harness = DeepAgentWindowsHarness(
        model="gemma3:1b",
        max_iterations=3,
        sandbox_memory_mb=256,
        sandbox_timeout=15,
    )

    start_time = time.time()
    try:
        final_state = harness.run(task=task, test_cases=test_suite)
        elapsed = time.time() - start_time

        console.print(f"\n[bold green]Harness Completed in {elapsed:.2f}s | Final Status: {final_state['status']}[/bold green]\n")

        # Display history table
        table = Table(title="Deep Agent Harness Execution Telemetry", border_style="cyan")
        table.add_column("Iter", justify="center", style="bold")
        table.add_column("Action", style="cyan")
        table.add_column("Result / Details", style="dim")

        for entry in final_state.get("history", []):
            action = entry.get("action", "")
            iter_num = str(entry.get("iteration", 1))
            if action == "generate_candidate":
                details = f"Generated {len(entry.get('code', ''))} chars of code"
            elif action == "sandbox_validation":
                res = entry.get("result", {})
                succ = res.get("success", False)
                details = f"Exit: {res.get('exit_code')} | Success: {succ} | Peak RAM: {res.get('memory_peak_mb', 0)}MB"
            elif action == "reflect_and_repair":
                details = f"Repaired code based on diagnosed error: {entry.get('error_diagnosed', '')[:50]}..."
            else:
                details = str(entry)
            table.add_row(iter_num, action, details)

        console.print(table)

        console.print("\n[bold green]Verified Candidate Code:[/bold green]")
        console.print(f"```python\n{final_state.get('code', '').strip()}\n```")

    finally:
        harness.close()


def run_official_deep_agent_demo():
    console.print(Panel.fit(
        "[bold green]Part 3: Official LangChain Deep Agent (`create_deep_agent`) + Windows Sandbox[/bold green]\n"
        "[dim]Full deep agent with autonomous planning, filesystem memory, and sandbox execute tool[/dim]",
        border_style="green"
    ))

    console.print("[yellow]Compiling official Deep Agent with WindowsStandaloneSandbox backend...[/yellow]")
    agent, sandbox = create_windows_deep_agent(
        model="gemma3:1b",
        max_memory_mb=256,
        default_timeout=20,
    )
    console.print(f"[green][OK][/green] Compiled Deep Agent: [bold]{type(agent).__name__}[/bold]")
    console.print(f"[green][OK][/green] Sandboxed Backend ID: [bold]{sandbox.id}[/bold]")
    console.print(f"[green][OK][/green] Workspace: [bold]{sandbox.workspace}[/bold]")
    console.print("[dim]The agent is equipped with: [bold]ls, read_file, write_file, edit_file, delete, glob, grep, execute, task[/bold][/dim]")
    
    # Clean up sandbox
    sandbox.close()


if __name__ == "__main__":
    console.print("\n[bold]=== LangChain Deep Agents Standalone Windows 11 LLM Harness ===[/bold]\n")
    run_standalone_sandbox_demo()
    console.print("\n" + "="*70 + "\n")
    run_loop_engineering_harness_demo()
    console.print("\n" + "="*70 + "\n")
    run_official_deep_agent_demo()
    console.print("\n[bold green]All demonstrations finished successfully![/bold green]\n")
