from windows_sandbox import WindowsStandaloneSandbox
from deepagents import create_deep_agent
from langchain_ollama import ChatOllama

def main():
    print("=== Test 1: Standard Execution ===")
    with WindowsStandaloneSandbox(max_memory_mb=128) as sbx:
        res = sbx.run_code('print("Hello from Windows 11 Standalone Sandbox!"); print("2+2=", 2 + 2)')
        print(f"Success: {res.success}")
        print(f"Output: {res.output.strip()}")
        assert res.success and "Hello from Windows" in res.output

    print("\n=== Test 2: Memory Limit Protection ===")
    with WindowsStandaloneSandbox(max_memory_mb=50) as sbx:
        res = sbx.run_code('data = bytearray(150 * 1024 * 1024); print("Allocated!")')
        print(f"Exit Code: {res.exit_code}")
        print(f"Success: {res.success}")
        print(f"Memory Error Caught: {'MemoryError' in res.output}")
        assert not res.success and "MemoryError" in res.output

    print("\n=== Test 3: Timeout Protection ===")
    with WindowsStandaloneSandbox(default_timeout=2) as sbx:
        res = sbx.run_code('import time\nwhile True:\n    time.sleep(0.1)')
        print(f"Exit Code: {res.exit_code}")
        print(f"Timed out: {res.timed_out}")
        assert res.timed_out

    print("\n=== Test 4: Filesystem Path Jail ===")
    with WindowsStandaloneSandbox() as sbx:
        try:
            sbx.resolve_safe_path("../../Windows/System32")
            print("Error: Failed to block traversal!")
            assert False
        except PermissionError as e:
            print(f"Blocked path traversal correctly: {e}")

    print("\n=== Test 5: Deep Agents Integration ===")
    sandbox = WindowsStandaloneSandbox()
    llm = ChatOllama(model="gemma3:1b", temperature=0.1)
    agent = create_deep_agent(model=llm, backend=sandbox)
    print(f"Deep Agent with Windows Sandbox compiled successfully: {type(agent)}")
    assert agent is not None

    print("\n==========================================")
    print("ALL SANDBOX VERIFICATION TESTS PASSED SUCCESSFULLY!")
    print("==========================================")

if __name__ == "__main__":
    main()
