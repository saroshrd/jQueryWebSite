# 🛠️ Complete Guide: Installing and Running Daytona Sandbox Locally

This guide walks you through setting up and running your own **local Daytona Sandbox server** on Windows (PowerShell/WSL2) or Linux/macOS.

---

## 📋 Prerequisites

1. **Docker Desktop** (or Docker Engine on Linux) must be installed and running.
   - On Windows, ensure **WSL 2 backend** is enabled in Docker Desktop settings.
2. **Python 3.10+** (already installed via Anaconda/virtualenv).

---

## ⚡ Step 1: Install the Daytona CLI

### On Windows (PowerShell):
Open PowerShell and run:
```powershell
$architecture = if ($env:PROCESSOR_ARCHITECTURE -eq "AMD64") { "amd64" } else { "arm64" }
md -Force "$Env:APPDATA\bin\daytona"
Invoke-WebRequest -URI "https://download.daytona.io/daytona/latest/daytona-windows-$architecture.exe" -OutFile "$Env:APPDATA\bin\daytona\daytona.exe"
$env:Path += ";$Env:APPDATA\bin\daytona"
[Environment]::SetEnvironmentVariable("Path", $env:Path, [System.EnvironmentVariableTarget]::User)
```

### On Linux, macOS, or WSL2:
```bash
curl -sf -L https://download.daytona.io/daytona/install.sh | sudo bash
```

Verify installation:
```powershell
daytona --version
```

---

## 🚀 Step 2: Start the Local Daytona Server

In your terminal, start the local Daytona server:
```powershell
daytona serve
```

* Daytona will automatically detect your local Docker daemon and set up the local sandbox runtime.
* The local API server will be listening at **`http://localhost:3000/api`**.
* **Keep this terminal window running in the background.**

---

## 🔑 Step 3: Generate Local API Key & Check Status

Open a **second terminal window** and run:

```powershell
# 1. Generate an API key for your local server:
daytona api-key generate

# 2. View server configuration details:
daytona server config
```

Copy the generated API key (e.g., `daytona_...`).

---

## 🔌 Step 4: Configure the Daytona Python SDK & Harness

Set your environment variables (or enter them directly in the Jupyter Notebook):

### PowerShell:
```powershell
$env:DAYTONA_API_URL = "http://localhost:3000/api"
$env:DAYTONA_API_KEY = "your_generated_api_key_here"
$env:DAYTONA_TARGET  = "local"
```

### Linux / macOS / WSL:
```bash
export DAYTONA_API_URL="http://localhost:3000/api"
export DAYTONA_API_KEY="your_generated_api_key_here"
export DAYTONA_TARGET="local"
```

---

## 🧪 Step 5: Test Daytona Sandbox in Python

Run this quick test script to verify your local Daytona sandbox:

```python
from daytona import Daytona, DaytonaConfig

# Connect to local Daytona server
config = DaytonaConfig(
    api_url="http://localhost:3000/api",
    api_key="your_generated_api_key_here",
    target="local"
)
client = Daytona(config)

# Create an isolated sandbox workspace
print("Creating Daytona Sandbox...")
sandbox = client.create()

try:
    # Run code snippet in sandbox
    response = sandbox.process.code_run('print("Hello from local Daytona Sandbox!")')
    print("Execution Result:", response.result)
    print("Exit Code:", response.exit_code)
finally:
    # Destroy sandbox when finished
    client.remove(sandbox)
    print("Sandbox cleaned up!")
```
