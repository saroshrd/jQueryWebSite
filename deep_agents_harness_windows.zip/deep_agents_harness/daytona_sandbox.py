"""
Daytona Sandbox Module for Deep Agents LLM Harness.
Connects to a local or remote Daytona Server to create isolated workspaces/sandboxes,
execute Python code snippets with `sandbox.process.code_run()`, and validate test assertions.
Includes an isolated local fallback when the local Daytona server is not yet running.
"""

import os
import sys
import time
import tempfile
import subprocess
from dataclasses import dataclass
from typing import Optional, Dict, Any


@dataclass
class DaytonaExecutionResult:
    """Structured execution result returned from Daytona Sandbox."""
    success: bool
    exit_code: int
    output: str
    error_message: Optional[str] = None
    execution_time: float = 0.0
    sandbox_id: Optional[str] = None
    backend: str = "daytona_local_server"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "exit_code": self.exit_code,
            "output": self.output,
            "error_message": self.error_message,
            "execution_time": round(self.execution_time, 3),
            "sandbox_id": self.sandbox_id,
            "backend": self.backend
        }

    def error_summary(self) -> str:
        if self.success:
            return "All test assertions passed successfully."
        return self.error_message or self.output.strip() or f"Execution failed with exit code {self.exit_code}"


class DaytonaSandboxRunner:
    """
    Daytona Sandbox Manager.
    Provisions ephemeral Daytona sandboxes and runs code validation.
    """

    def __init__(
        self,
        api_url: Optional[str] = None,
        api_key: Optional[str] = None,
        target: str = "local",
        timeout: int = 15,
        reuse_sandbox: bool = False
    ):
        self.api_url = api_url or os.environ.get("DAYTONA_API_URL", "http://localhost:3000/api")
        self.api_key = api_key or os.environ.get("DAYTONA_API_KEY", "")
        self.target = target or os.environ.get("DAYTONA_TARGET", "local")
        self.timeout = timeout
        self.reuse_sandbox = reuse_sandbox
        self._shared_sandbox = None

    def validate_code_with_tests(
        self,
        code: str,
        test_cases: str
    ) -> DaytonaExecutionResult:
        """
        Runs candidate code followed by test assertions inside the Daytona sandbox.
        """
        combined_payload = (
            "# === CANDIDATE IMPLEMENTATION ===\n"
            f"{code.strip()}\n\n"
            "# === TEST SUITE VALIDATION ===\n"
            f"{test_cases.strip()}\n"
        )

        try:
            return self._run_in_daytona(combined_payload)
        except Exception as e:
            # Fall back to isolated local runner if Daytona daemon is unreachable
            return self._run_in_local_fallback(combined_payload, reason=str(e))

    def _run_in_daytona(self, full_code: str) -> DaytonaExecutionResult:
        """Executes code inside a real Daytona sandbox."""
        from daytona import Daytona, DaytonaConfig

        config = DaytonaConfig(
            api_url=self.api_url,
            api_key=self.api_key,
            target=self.target
        )
        client = Daytona(config)

        start_time = time.perf_counter()
        sandbox = None

        try:
            # Provision or reuse Daytona sandbox workspace
            sandbox = client.create()
            sandbox_id = getattr(sandbox, "id", "local_sandbox")

            # Execute code in sandbox
            response = sandbox.process.code_run(full_code)
            elapsed = time.perf_counter() - start_time

            exit_code = getattr(response, "exit_code", 0)
            result_output = getattr(response, "result", "") or ""
            success = (exit_code == 0)

            return DaytonaExecutionResult(
                success=success,
                exit_code=exit_code,
                output=result_output,
                error_message=None if success else (result_output or "Execution returned non-zero exit code"),
                execution_time=elapsed,
                sandbox_id=str(sandbox_id),
                backend="Daytona Local Server Sandbox"
            )

        finally:
            if sandbox and not self.reuse_sandbox:
                try:
                    client.remove(sandbox)
                except Exception:
                    pass

    def _run_in_local_fallback(self, full_code: str, reason: str = "") -> DaytonaExecutionResult:
        """
        Local process isolation fallback when Daytona server is offline.
        Provides matching contract and stdout/stderr capture.
        """
        start_time = time.perf_counter()
        with tempfile.TemporaryDirectory(prefix="daytona_local_emulation_") as temp_dir:
            script_path = os.path.join(temp_dir, "solution_test.py")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(full_code)

            clean_env = {
                k: v for k, v in os.environ.items()
                if k.upper() in {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "PYTHONPATH"}
            }
            clean_env["PYTHONIOENCODING"] = "utf-8"

            try:
                proc = subprocess.run(
                    [sys.executable, script_path],
                    cwd=temp_dir,
                    env=clean_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=self.timeout,
                    encoding="utf-8",
                    errors="replace"
                )
                elapsed = time.perf_counter() - start_time
                success = (proc.returncode == 0)

                output = proc.stdout if success else (proc.stderr or proc.stdout)
                return DaytonaExecutionResult(
                    success=success,
                    exit_code=proc.returncode,
                    output=output,
                    error_message=None if success else proc.stderr,
                    execution_time=elapsed,
                    sandbox_id="local_fallback_proc",
                    backend=f"Local Process Sandbox (Daytona server offline: {reason[:60]}...)"
                )
            except subprocess.TimeoutExpired:
                elapsed = time.perf_counter() - start_time
                return DaytonaExecutionResult(
                    success=False,
                    exit_code=-1,
                    output="",
                    error_message=f"Timeout expired after {self.timeout}s",
                    execution_time=elapsed,
                    sandbox_id="local_fallback_proc",
                    backend="Local Process Sandbox"
                )
