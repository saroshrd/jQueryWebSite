"""
Generates the interactive deep_agents_harness_windows.ipynb Jupyter Notebook.
"""
import json

notebook = {
    "cells": [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# \U0001f680 LangChain Deep Agents Standalone LLM Harness (Windows 11)\n",
                "### Native Windows NT Kernel Job Object Sandboxing | Zero-Docker & Zero-Podman\n",
                "\n",
                "This notebook provides a complete guide and runnable code harness for **LangChain Deep Agents** (`deepagents`) and **LangGraph**, utilizing an open-source, container-free **Windows 11 Standalone Sandbox**.\n",
                "\n",
                "### \U0001f512 Why Standalone Windows NT Kernel Sandboxing?\n",
                "- **No Docker/Podman Daemon**: Runs natively on bare-metal Windows 11 without WSL2 or Hyper-V overhead.\n",
                "- **Kernel Hard Memory Caps**: Windows NT Job Objects (`JOB_OBJECT_LIMIT_PROCESS_MEMORY` / `JOB_OBJECT_LIMIT_JOB_MEMORY`) instantly abort memory exhaustion and runaway allocations with `MemoryError`.\n",
                "- **Kill-on-Close & Timeouts**: `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` and `TerminateJobObject` guarantee zero orphan background processes or hung child forks.\n",
                "- **Path Jailing**: Blocks directory traversal (`..`, `C:\\Windows`) and isolates temp directories (`TEMP`, `TMP`, `USERPROFILE`).\n",
                "- **Official `BaseSandbox` Implementation**: Drop-in backend for LangChain's official `deepagents.create_deep_agent`."
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 1. Setup & Environment Verification"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "import sys, os\n",
                "from rich.console import Console\n",
                "from rich.panel import Panel\n",
                "\n",
                "# Import standalone sandbox and deep agent harness\n",
                "from windows_sandbox import WindowsStandaloneSandbox, SandboxExecutionResult\n",
                "from deep_agent_harness import DeepAgentWindowsHarness, create_windows_deep_agent\n",
                "\n",
                "console = Console(highlight=False)\n",
                "print(f\"Python Runtime: {sys.version.split()[0]} on {sys.platform}\")\n",
                "console.print(\"[bold green]Modules loaded successfully![/bold green]\")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 2. Windows 11 Kernel Sandboxing Verification\n",
                "Let's verify that the standalone sandbox enforces:\n",
                "1. Benign code execution\n",
                "2. Kernel memory limits (intercepting 300MB allocation inside a 128MB ceiling)\n",
                "3. Execution timeouts and runaway process termination\n",
                "4. Directory traversal blocking"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "with WindowsStandaloneSandbox(max_memory_mb=128, default_timeout=5) as sbx:\n",
                "    console.print(f\"[cyan]Sandbox ID:[/] {sbx.id}\")\n",
                "    console.print(f\"[cyan]Workspace Root:[/] {sbx.workspace}\")\n",
                "\n",
                "    # 1. Benign Execution\n",
                "    res_normal = sbx.run_code('import math; print(f\"Calculated Pi: {math.pi:.6f}\")')\n",
                "    console.print(f\"[green]{res_normal.summary()}[/green]\")\n",
                "\n",
                "    # 2. Kernel Memory Limit Protection (allocating 300MB with 128MB limit)\n",
                "    res_oom = sbx.run_code('arr = bytearray(300 * 1024 * 1024)')\n",
                "    console.print(f\"[yellow]OOM Test:[/] Exit {res_oom.exit_code} | MemoryError Caught: {'MemoryError' in res_oom.output}\")\n",
                "\n",
                "    # 3. Timeout Protection\n",
                "    res_timeout = sbx.run_code('import time\\nwhile True: time.sleep(0.1)', timeout=2)\n",
                "    console.print(f\"[yellow]Timeout Test:[/] Timed out: {res_timeout.timed_out} | Exit code: {res_timeout.exit_code}\")\n",
                "\n",
                "    # 4. Path Traversal Jail Test\n",
                "    try:\n",
                "        sbx.resolve_safe_path('../../Windows/System32')\n",
                "        console.print(\"[bold red]FAILED:[/] Traversal was not blocked!\")\n",
                "    except PermissionError as e:\n",
                "        console.print(f\"[bold green][OK] Traversal blocked by Sandbox:[/] {e}\")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 3. Deep Agent Evaluation Harness (Loop Engineering)\n",
                "We now run the autonomous iterative evaluation loop:\n",
                "- **QA Node**: Automatically prepares or validates unit assertions.\n",
                "- **Candidate Gen Node**: Ollama (`gemma3:1b`) writes initial implementation.\n",
                "- **Sandbox Validation Node**: Executes code + tests in `WindowsStandaloneSandbox`.\n",
                "- **Reflect & Repair Node**: Diagnoses tracebacks and auto-patches failing code."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "task = \"Write a function `is_prime(n: int) -> bool` that returns True if n is prime, and False for n <= 1 or composites. Optimize for edge cases.\"\n",
                "\n",
                "test_suite = \"\"\"\n",
                "assert is_prime(2) == True\n",
                "assert is_prime(3) == True\n",
                "assert is_prime(4) == False\n",
                "assert is_prime(17) == True\n",
                "assert is_prime(1) == False\n",
                "assert is_prime(0) == False\n",
                "assert is_prime(-7) == False\n",
                "assert is_prime(97) == True\n",
                "print('ALL PRIME TESTS PASSED IN WINDOWS STANDALONE SANDBOX!')\n",
                "\"\"\"\n",
                "\n",
                "harness = DeepAgentWindowsHarness(\n",
                "    model=\"gemma3:1b\",\n",
                "    max_iterations=3,\n",
                "    sandbox_memory_mb=256,\n",
                "    sandbox_timeout=15\n",
                ")\n",
                "\n",
                "try:\n",
                "    result = harness.run(task=task, test_cases=test_suite)\n",
                "    console.print(f\"[bold green]Final Status: {result['status']} in {result['iteration']} iteration(s)[/bold green]\")\n",
                "    console.print(\"\\n[cyan]Final Verified Code:[/cyan]\")\n",
                "    print(result[\"code\"].strip())\n",
                "finally:\n",
                "    harness.close()"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 4. Official LangChain Deep Agent (`create_deep_agent`)\n",
                "Instantiates LangChain's official `create_deep_agent` with our `WindowsStandaloneSandbox` backend, exposing tools like `ls`, `read_file`, `write_file`, `edit_file`, and `execute`."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "agent, sandbox = create_windows_deep_agent(\n",
                "    model=\"gemma3:1b\",\n",
                "    max_memory_mb=256,\n",
                "    default_timeout=20\n",
                ")\n",
                "\n",
                "console.print(f\"[green][OK][/green] Compiled Deep Agent Graph: [bold]{type(agent).__name__}[/bold]\")\n",
                "console.print(f\"[green][OK][/green] Sandboxed Backend ID: [bold]{sandbox.id}[/bold]\")\n",
                "console.print(f\"[green][OK][/green] Active Workspace: [bold]{sandbox.workspace}[/bold]\")\n",
                "\n",
                "# Execute a command directly via the sandbox backend protocol\n",
                "exec_resp = sandbox.execute(\"python3 -c \\\"print('Verified direct BaseSandbox protocol execution!')\\\"\")\n",
                "print(\"BaseSandbox Execute Response:\", exec_resp)\n",
                "\n",
                "sandbox.close()"
            ]
        }
    ],
    "metadata": {
        "language_info": {
            "name": "python"
        }
    },
    "nbformat": 4,
    "nbformat_minor": 2
}

with open("C:/Users/Sarosh/.gemini/antigravity/scratch/deep_agents_harness/deep_agents_harness_windows.ipynb", "w", encoding="utf-8") as f:
    json.dump(notebook, f, indent=2)

print("Notebook generated successfully!")
