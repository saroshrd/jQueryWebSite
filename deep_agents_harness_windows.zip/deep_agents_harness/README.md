# 🚀 Standalone LangChain Deep Agents LLM Harness (Windows 11)
### Native Windows NT Kernel Job Object Sandboxing | Zero-Docker & Zero-Podman

A production-grade autonomous LLM code evaluation and execution harness built with **LangChain**, **LangGraph**, and the official **Deep Agents** architecture (`deepagents`), powered locally by **Ollama (`gemma3:1b`)** and native Windows 11 kernel sandboxing.

---

## 💡 Why Windows NT Kernel Sandboxing (No Containers)?

Traditional sandboxing solutions (Docker, Podman, Daytona, E2B) require background container daemons, Hyper-V, WSL2, or remote cloud subscriptions. 

This project implements **`WindowsStandaloneSandbox`**, a standalone isolation engine utilizing **Windows NT Kernel Job Objects** (`kernel32.dll`) and OS-level primitives directly from Python standard library (`ctypes`):

| Security Layer | Mechanism | Protection |
| :--- | :--- | :--- |
| **Physical Memory Limit** | `JOB_OBJECT_LIMIT_PROCESS_MEMORY` & `JOB_OBJECT_LIMIT_JOB_MEMORY` | Hard ceiling (e.g., 256MB/512MB). The kernel immediately aborts runaway allocations with `MemoryError`. |
| **Process Count Cap** | `JOB_OBJECT_LIMIT_ACTIVE_PROCESS` | Limits maximum concurrent child processes (mitigating fork-bombs). |
| **Zero Orphan Processes** | `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` | Closing the job handle or terminating the parent process automatically kills all child/grandchild processes. |
| **Hard Timeouts** | `kernel32.TerminateJobObject(job, 124)` | Instantly terminates hung scripts or infinite loops. |
| **Path Jailing** | Ephemeral Root Workspace & Strict Traversal Checks | Blocks directory traversal (`..`, `C:\Windows`) with `PermissionError`. |
| **Environment Sanitization** | Minimal Environment Whitelist | Strips all host API keys, secrets, and cloud tokens. Redirects `%TEMP%` inside the sandbox workspace. |

---

## 📋 System Architecture

```
                                  [ User Task ]
                                        │
                                        ▼
                        ┌───────────────────────────────┐
                        │   1. Test Suite Preparation   │
                        │      (QA Assertion Node)      │
                        └───────────────┬───────────────┘
                                        │
                                        ▼
                        ┌───────────────────────────────┐
                        │   2. Candidate Code Gen Node  │
                        │      (Ollama gemma3:1b)       │
                        └───────────────┬───────────────┘
                                        │ (Code + Test Suite)
                                        ▼
                        ┌───────────────────────────────┐
                        │   3. WINDOWS 11 STANDALONE    │
                        │            SANDBOX            │
                        │  - Windows NT Job Object      │
                        │  - Hard RAM & CPU Quotas      │
                        │  - Zero Docker / Zero Podman  │
                        └───────────────┬───────────────┘
                                        │
                            Test Assertion Execution
                                        │
                 ┌──────────────────────┴──────────────────────┐
                 │                                             │
      [ Exit Code == 0 & Tests Pass ]               [ Exit != 0 or AssertionError ]
                 │                                             │
                 ▼                                             ▼
          🏆 FINISHED                            ┌───────────────────────────┐
     Verified Working Code                       │ 4. Reflect & Repair Loop  │
                                                 │    (Ollama gemma3:1b)     │
                                                 │ - Analyzes Traceback      │
                                                 │ - Patches Failing Logic   │
                                                 └─────────────┬─────────────┘
                                                               │
                                                               └──▶ Loop back to Sandbox
                                                                   (up to max_iterations)
```

---

## 🛠️ Quickstart

### 1. Requirements
- **Windows 11** (64-bit)
- **Python 3.10+** (tested on 3.12)
- **Ollama** running locally with `gemma3:1b` (or `gemma4:e2b`, `phi4-mini`):
  ```powershell
  ollama run gemma3:1b
  ```

### 2. Setup Virtual Environment
```powershell
# Using uv (recommended) or standard venv:
uv venv .venv --python 3.12
.\.venv\Scripts\activate
uv pip install -r requirements.txt
```

### 3. Run the Demonstration
Execute the full standalone verification and evaluation demo:
```powershell
python run_demo.py
```

### 4. Interactive Jupyter Notebook
Open [`deep_agents_harness_windows.ipynb`](./deep_agents_harness_windows.ipynb) in **VS Code** with the `.venv` Python kernel selected to interactively test kernel memory ceilings, timeout kills, and deep agent loops.

---

## 🧩 Usage Modes

### Mode A: LangGraph Reflexive Loop Engineering Harness
```python
from deep_agent_harness import DeepAgentWindowsHarness

harness = DeepAgentWindowsHarness(
    model="gemma3:1b",
    max_iterations=3,
    sandbox_memory_mb=256,
    sandbox_timeout=15
)

result = harness.run(
    task="Write a function `fibonacci(n: int) -> int` that computes the nth Fibonacci number.",
    test_cases="assert fibonacci(7) == 13\nprint('ALL TESTS PASSED!')"
)

print(result["code"])
harness.close()
```

### Mode B: Official LangChain Deep Agents Harness (`create_deep_agent`)
```python
from deep_agent_harness import create_windows_deep_agent

# Compiles an official Deep Agent equipped with:
# ls, read_file, write_file, edit_file, delete, glob, grep, execute, task
agent, sandbox = create_windows_deep_agent(
    model="gemma3:1b",
    max_memory_mb=256,
    default_timeout=20
)

# Run direct sandbox commands or let the agent autonomously plan & execute
res = sandbox.execute("python3 -c \"print('Hello from Windows Sandbox!')\"")
print(res.output)

sandbox.close()
```

---

## 📁 Repository Structure

- **`windows_sandbox.py`**: Standalone Windows 11 sandbox engine implementing LangChain's `BaseSandbox` using Windows NT Kernel Job Objects.
- **`deep_agent_harness.py`**: LangChain / LangGraph deep agent harness and loop engineering workflow.
- **`run_demo.py`**: Complete CLI demonstration of standalone sandboxing, kernel limit enforcement, and LLM evaluation.
- **`deep_agents_harness_windows.ipynb`**: Interactive VS Code Jupyter notebook.
- **`requirements.txt`**: Package dependencies (no Docker or Daytona needed).
