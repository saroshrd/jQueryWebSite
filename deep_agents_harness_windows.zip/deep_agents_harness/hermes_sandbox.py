"""
Hermes Sandbox - Isolated Code Execution Environment
Inspired by Nous Research Hermes Agent code execution paradigm.

Features:
- Ephemeral workspace directory isolation per execution
- Environment variable sanitization (strips API keys and host secrets)
- Hard timeout enforcement against infinite loops
- Structured execution feedback (stdout, stderr, exit_code, duration)
- Support for both local Subprocess isolation and ephemeral Docker containers
"""

import os
import sys
import time
import shutil
import tempfile
import subprocess
from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class HermesSandboxResult:
    """Structured result returned by the Hermes Sandbox."""
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    execution_time: float
    timed_out: bool = False
    error_message: Optional[str] = None
    sandbox_dir: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "execution_time": round(self.execution_time, 3),
            "timed_out": self.timed_out,
            "error_message": self.error_message
        }

    def summary(self) -> str:
        if self.success:
            return f"PASSED in {self.execution_time:.2f}s\nOutput:\n{self.stdout.strip()}"
        elif self.timed_out:
            return f"TIMEOUT ({self.execution_time:.2f}s): Code exceeded maximum execution window."
        else:
            err = self.stderr.strip() or self.error_message or "Unknown error"
            return f"FAILED (exit code {self.exit_code}) in {self.execution_time:.2f}s\nError:\n{err}"


class HermesSandbox:
    """
    Hermes Sandbox Executor
    Provides isolated sandboxing for LLM-generated Python code.
    """

    ALLOWED_ENV_VARS = {
        "PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP",
        "PYTHONPATH", "PYTHONHOME", "PYTHONIOENCODING", "LANG", "LC_ALL"
    }

    def __init__(
        self,
        backend: str = "subprocess",  # "subprocess" or "docker"
        docker_image: str = "python:3.11-slim",
        default_timeout: int = 10,
        python_executable: Optional[str] = None
    ):
        self.backend = backend.lower()
        self.docker_image = docker_image
        self.default_timeout = default_timeout
        self.python_executable = python_executable or sys.executable

    def _sanitize_environment(self) -> Dict[str, str]:
        """Strip sensitive host environment variables (API keys, credentials, tokens)."""
        clean_env = {}
        for k, v in os.environ.items():
            if k.upper() in self.ALLOWED_ENV_VARS:
                clean_env[k] = v
        # Ensure utf-8 encoding for reliable stream capture
        clean_env["PYTHONIOENCODING"] = "utf-8"
        clean_env["PYTHONUNBUFFERED"] = "1"
        return clean_env

    def execute_code(
        self,
        code: str,
        timeout: Optional[int] = None,
        preserve_workspace: bool = False
    ) -> HermesSandboxResult:
        """
        Executes Python code in a sandboxed directory with strict timeout and environment isolation.
        """
        timeout = timeout or self.default_timeout

        if self.backend == "docker":
            return self._execute_docker(code, timeout)
        else:
            return self._execute_subprocess(code, timeout, preserve_workspace)

    def _execute_subprocess(
        self,
        code: str,
        timeout: int,
        preserve_workspace: bool
    ) -> HermesSandboxResult:
        sandbox_dir = tempfile.mkdtemp(prefix="hermes_sandbox_")
        script_path = os.path.join(sandbox_dir, "solution.py")

        with open(script_path, "w", encoding="utf-8") as f:
            f.write(code)

        start_time = time.perf_counter()
        clean_env = self._sanitize_environment()

        try:
            proc = subprocess.run(
                [self.python_executable, script_path],
                cwd=sandbox_dir,
                env=clean_env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=timeout,
                encoding="utf-8",
                errors="replace"
            )
            elapsed = time.perf_counter() - start_time
            success = (proc.returncode == 0)

            return HermesSandboxResult(
                success=success,
                exit_code=proc.returncode,
                stdout=proc.stdout,
                stderr=proc.stderr,
                execution_time=elapsed,
                timed_out=False,
                error_message=None if success else (proc.stderr or f"Non-zero exit code: {proc.returncode}"),
                sandbox_dir=sandbox_dir if preserve_workspace else None
            )

        except subprocess.TimeoutExpired as e:
            elapsed = time.perf_counter() - start_time
            return HermesSandboxResult(
                success=False,
                exit_code=-1,
                stdout=e.stdout or "" if isinstance(e.stdout, str) else "",
                stderr=e.stderr or "" if isinstance(e.stderr, str) else "",
                execution_time=elapsed,
                timed_out=True,
                error_message=f"Execution timed out after {timeout} seconds",
                sandbox_dir=sandbox_dir if preserve_workspace else None
            )
        except Exception as ex:
            elapsed = time.perf_counter() - start_time
            return HermesSandboxResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr=str(ex),
                execution_time=elapsed,
                timed_out=False,
                error_message=f"Sandbox harness failure: {str(ex)}",
                sandbox_dir=sandbox_dir if preserve_workspace else None
            )
        finally:
            if not preserve_workspace and os.path.exists(sandbox_dir):
                try:
                    shutil.rmtree(sandbox_dir, ignore_errors=True)
                except Exception:
                    pass

    def _execute_docker(self, code: str, timeout: int) -> HermesSandboxResult:
        """Runs the code inside an isolated ephemeral Docker container."""
        sandbox_dir = tempfile.mkdtemp(prefix="hermes_docker_")
        script_path = os.path.join(sandbox_dir, "solution.py")

        with open(script_path, "w", encoding="utf-8") as f:
            f.write(code)

        start_time = time.perf_counter()
        docker_cmd = [
            "docker", "run", "--rm",
            "--network", "none",                   # No external network access
            "--memory", "256m",                    # Memory limit
            "--cpus", "1.0",                       # CPU limit
            "-v", f"{sandbox_dir}:/sandbox:ro",     # Read-only mount
            "-w", "/sandbox",
            self.docker_image,
            "python", "solution.py"
        ]

        try:
            proc = subprocess.run(
                docker_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=timeout,
                encoding="utf-8",
                errors="replace"
            )
            elapsed = time.perf_counter() - start_time
            success = (proc.returncode == 0)

            return HermesSandboxResult(
                success=success,
                exit_code=proc.returncode,
                stdout=proc.stdout,
                stderr=proc.stderr,
                execution_time=elapsed,
                timed_out=False,
                error_message=None if success else proc.stderr
            )
        except subprocess.TimeoutExpired:
            elapsed = time.perf_counter() - start_time
            return HermesSandboxResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr=f"Docker container timed out after {timeout}s",
                execution_time=elapsed,
                timed_out=True,
                error_message=f"Docker container timed out after {timeout}s"
            )
        except Exception as ex:
            # Fall back to subprocess mode if docker daemon is unavailable
            return self._execute_subprocess(code, timeout, preserve_workspace=False)
        finally:
            if os.path.exists(sandbox_dir):
                shutil.rmtree(sandbox_dir, ignore_errors=True)
