"""
E2B Sandboxing Module for Deep Agents LLM Harness.
Supports:
  1. Local E2B Embed (Self-hosted E2B runtime via Docker Compose / localhost)
  2. Local Docker Container Sandbox (Zero cloud, isolated container)
  3. Local Process Isolation (Zero dependency local fallback)
  4. E2B Cloud Sandbox (Managed cloud)
"""

import os
import sys
import time
import shutil
import tempfile
import subprocess
from dataclasses import dataclass
from typing import Optional, Dict, Any, List


@dataclass
class E2BExecutionResult:
    """Standardized result from E2B Sandbox execution."""
    success: bool
    stdout: str
    stderr: str
    error_name: Optional[str] = None
    error_value: Optional[str] = None
    traceback: Optional[str] = None
    execution_time: float = 0.0
    backend: str = "local_e2b_embed"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "error_name": self.error_name,
            "error_value": self.error_value,
            "traceback": self.traceback,
            "execution_time": round(self.execution_time, 3),
            "backend": self.backend
        }

    def error_summary(self) -> str:
        if self.success:
            return "All test cases passed successfully."
        if self.traceback:
            return self.traceback.strip()
        if self.error_name:
            return f"{self.error_name}: {self.error_value}"
        return self.stderr.strip() or "Unknown execution failure"


class E2BSandboxRunner:
    """
    Manages code execution and test validation inside local or cloud E2B Sandboxes.
    """

    def __init__(
        self,
        mode: str = "local_embed",  # "local_embed", "local_docker", "local_process", or "e2b_cloud"
        local_url: str = "http://localhost:3000",
        local_domain: str = "localhost",
        api_key: Optional[str] = None,
        timeout: int = 15,
        docker_image: str = "python:3.11-slim"
    ):
        self.mode = mode.lower()
        self.local_url = local_url
        self.local_domain = local_domain
        self.api_key = api_key or os.environ.get("E2B_API_KEY", "e2b_local_team_api_key_12345")
        self.timeout = timeout
        self.docker_image = docker_image

        # Configure environment variables for self-hosted local E2B if in local_embed mode
        if self.mode == "local_embed":
            os.environ["E2B_API_URL"] = self.local_url
            os.environ["E2B_DOMAIN"] = self.local_domain
            os.environ["E2B_API_KEY"] = self.api_key

    def validate_code_with_tests(
        self,
        code: str,
        test_cases: str
    ) -> E2BExecutionResult:
        """
        Executes candidate code followed by test assertions inside the sandbox.
        """
        combined_payload = (
            "# === CANDIDATE IMPLEMENTATION ===\n"
            f"{code.strip()}\n\n"
            "# === TEST SUITE VALIDATION ===\n"
            f"{test_cases.strip()}\n"
        )

        if self.mode in ("local_embed", "e2b_cloud"):
            return self._run_in_e2b_sdk(combined_payload)
        elif self.mode == "local_docker":
            return self._run_in_local_docker(combined_payload)
        else:
            return self._run_in_local_process(combined_payload)

    def _run_in_e2b_sdk(self, full_code: str) -> E2BExecutionResult:
        """
        Executes code using the official E2B SDK.
        If self.mode == 'local_embed', it connects to the local E2B instance via E2B_API_URL and E2B_DOMAIN.
        """
        try:
            from e2b_code_interpreter import Sandbox
        except ImportError:
            print("⚠️ `e2b-code-interpreter` SDK not installed. Falling back to local process sandbox.")
            return self._run_in_local_process(full_code)

        start_time = time.perf_counter()
        backend_name = "Local E2B Embed (Self-Hosted)" if self.mode == "local_embed" else "E2B Cloud"

        try:
            # Connect to local or cloud E2B sandbox instance
            with Sandbox.create(api_key=self.api_key, timeout=self.timeout) as sandbox:
                execution = sandbox.run_code(full_code)
                elapsed = time.perf_counter() - start_time

                stdout = "\n".join(execution.logs.stdout) if execution.logs and execution.logs.stdout else ""
                stderr = "\n".join(execution.logs.stderr) if execution.logs and execution.logs.stderr else ""

                if execution.error:
                    return E2BExecutionResult(
                        success=False,
                        stdout=stdout,
                        stderr=stderr,
                        error_name=execution.error.name,
                        error_value=execution.error.value,
                        traceback=execution.error.traceback,
                        execution_time=elapsed,
                        backend=backend_name
                    )

                return E2BExecutionResult(
                    success=True,
                    stdout=stdout or execution.text or "All test cases passed.",
                    stderr=stderr,
                    execution_time=elapsed,
                    backend=backend_name
                )

        except Exception as e:
            elapsed = time.perf_counter() - start_time
            print(f"⚠️ Could not reach E2B at {self.local_url}: {e}. Falling back to local process sandbox.")
            fallback_res = self._run_in_local_process(full_code)
            fallback_res.backend = f"Fallback (Local E2B unreachable at {self.local_url})"
            return fallback_res

    def _run_in_local_docker(self, full_code: str) -> E2BExecutionResult:
        """Runs the code in an isolated local Docker container with no network access."""
        start_time = time.perf_counter()
        sandbox_dir = tempfile.mkdtemp(prefix="e2b_local_docker_")
        script_path = os.path.join(sandbox_dir, "solution.py")

        with open(script_path, "w", encoding="utf-8") as f:
            f.write(full_code)

        docker_cmd = [
            "docker", "run", "--rm",
            "--network", "none",
            "--memory", "512m",
            "--cpus", "1.0",
            "-v", f"{sandbox_dir}:/sandbox:ro",
            "-w", "/sandbox",
            self.docker_image,
            "python", "solution.py"
        ]

        try:
            proc = subprocess.run(
                docker_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self.timeout,
                encoding="utf-8",
                errors="replace"
            )
            elapsed = time.perf_counter() - start_time
            success = (proc.returncode == 0)

            return E2BExecutionResult(
                success=success,
                stdout=proc.stdout,
                stderr=proc.stderr,
                error_name="AssertionError" if not success else None,
                error_value=proc.stderr.strip().splitlines()[-1] if not success and proc.stderr.strip() else None,
                traceback=proc.stderr if not success else None,
                execution_time=elapsed,
                backend="Local Isolated Docker Container"
            )
        except subprocess.TimeoutExpired:
            elapsed = time.perf_counter() - start_time
            return E2BExecutionResult(
                success=False,
                stdout="",
                stderr=f"Docker execution timed out after {self.timeout}s",
                traceback=f"TimeoutError: execution exceeded {self.timeout}s",
                execution_time=elapsed,
                backend="Local Isolated Docker Container"
            )
        except Exception as ex:
            return self._run_in_local_process(full_code)
        finally:
            shutil.rmtree(sandbox_dir, ignore_errors=True)

    def _run_in_local_process(self, full_code: str) -> E2BExecutionResult:
        """Lightweight local process isolation (ephemeral directory, stripped host environment)."""
        start_time = time.perf_counter()
        with tempfile.TemporaryDirectory(prefix="e2b_local_process_") as temp_dir:
            script_path = os.path.join(temp_dir, "test_payload.py")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(full_code)

            clean_env = {
                k: v for k, v in os.environ.items()
                if k.upper() in {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "PYTHONPATH"}
            }
            clean_env["PYTHONIOENCODING"] = "utf-8"

            try:
                proc = subprocess.run(
                    [sys.executable, script_path],
                    cwd=temp_dir,
                    env=clean_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=self.timeout,
                    encoding="utf-8",
                    errors="replace"
                )
                elapsed = time.perf_counter() - start_time
                success = (proc.returncode == 0)

                return E2BExecutionResult(
                    success=success,
                    stdout=proc.stdout,
                    stderr=proc.stderr,
                    error_name="AssertionError" if not success else None,
                    error_value=proc.stderr.strip().splitlines()[-1] if not success and proc.stderr.strip() else None,
                    traceback=proc.stderr if not success else None,
                    execution_time=elapsed,
                    backend="Local Process Sandbox"
                )
            except subprocess.TimeoutExpired:
                elapsed = time.perf_counter() - start_time
                return E2BExecutionResult(
                    success=False,
                    stdout="",
                    stderr=f"Timeout expired after {self.timeout}s",
                    traceback=f"TimeoutError: execution exceeded {self.timeout}s",
                    execution_time=elapsed,
                    backend="Local Process Sandbox"
                )
