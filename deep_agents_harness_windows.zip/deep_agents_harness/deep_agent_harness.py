"""
Deep Agents LLM Harness for Windows 11 (Standalone, Zero-Docker / Zero-Podman).
Powered by LangChain, LangGraph, and Windows NT Kernel Job Object Sandboxing.

Features:
1. Standalone Execution on Windows 11:
   - Uses `WindowsStandaloneSandbox` with native kernel Job Object resource limits.
   - Enforces RAM limits, active process limits, and kill-on-close guarantees.
   - Blocks path traversal and scrubs environment secrets.
2. Official LangChain Deep Agents Harness (`create_deep_agent`):
   - Autonomous planning, virtual filesystem workspace, and sandboxed tool execution.
3. LangGraph Reflexive Loop Engineering:
   - Automated test-suite preparation.
   - Candidate code generation.
   - Sandboxed test execution and assertion evaluation.
   - Self-reflection & auto-repair loop with traceback diagnosis.
"""

from __future__ import annotations

import re
import sys
from typing import TypedDict, List, Dict, Any, Optional, Union
from dataclasses import asdict

from langchain_core.messages import SystemMessage, HumanMessage, BaseMessage
from langchain_core.language_models.chat_models import BaseChatModel
from langgraph.graph import StateGraph, END

# Import the standalone Windows sandbox engine
from windows_sandbox import (
    WindowsStandaloneSandbox,
    SandboxExecutionResult,
)

# Optional import of official Deep Agents harness
try:
    from deepagents import create_deep_agent
    DEEPAGENTS_AVAILABLE = True
except ImportError:
    DEEPAGENTS_AVAILABLE = False


# ============================================================================
# State Schema for LangGraph Harness Workflow
# ============================================================================

class DeepAgentHarnessState(TypedDict):
    task: str
    test_cases: str
    code: str
    iteration: int
    max_iterations: int
    sandbox_result: Dict[str, Any]
    reflection: str
    status: str
    history: List[Dict[str, Any]]


def extract_python_code(raw_llm_response: str) -> str:
    """Extracts executable Python code from markdown code fences or plain text."""
    pattern = r"```(?:python)?\s*\n(.*?)```"
    matches = re.findall(pattern, raw_llm_response, re.DOTALL | re.IGNORECASE)
    if matches:
        return max(matches, key=len).strip()

    lines = raw_llm_response.strip().splitlines()
    clean = [line for line in lines if not line.strip().startswith("```")]
    return "\n".join(clean).strip()


# ============================================================================
# Standalone Windows 11 Deep Agent Harness
# ============================================================================

class DeepAgentWindowsHarness:
    """
    Autonomous LangChain & LangGraph Deep Agent Evaluation Harness for Windows 11.
    
    Zero Docker / Zero Podman:
    - Runs standalone on Windows 11 with Windows NT Job Object isolation.
    - Validates candidate implementations against test suites.
    - Features self-reflection and iterative bug repair.
    """

    def __init__(
        self,
        model: Optional[Union[str, BaseChatModel]] = "gemma3:1b",
        ollama_base_url: str = "http://127.0.0.1:11434",
        max_iterations: int = 4,
        sandbox_memory_mb: int = 256,
        sandbox_timeout: int = 15,
        workspace_dir: Optional[str] = None
    ):
        self.max_iterations = max_iterations
        self.sandbox_timeout = sandbox_timeout
        self.sandbox_memory_mb = sandbox_memory_mb

        # Initialize LLM (Ollama or custom BaseChatModel)
        if isinstance(model, BaseChatModel):
            self.llm = model
            self.model_name = getattr(model, "model_name", getattr(model, "model", "custom_chat_model"))
        else:
            try:
                from langchain_ollama import ChatOllama
                self.model_name = model or "gemma3:1b"
                self.llm = ChatOllama(
                    model=self.model_name,
                    base_url=ollama_base_url,
                    temperature=0.1
                )
            except Exception:
                raise RuntimeError(
                    "langchain-ollama is required for string model names. "
                    "Alternatively, pass an instantiated BaseChatModel."
                )

        # Initialize standalone sandbox engine
        self.sandbox = WindowsStandaloneSandbox(
            workspace_dir=workspace_dir,
            max_memory_mb=sandbox_memory_mb,
            default_timeout=sandbox_timeout,
            cleanup_on_close=False,  # Retain workspace during harness run
        )

        # Compile LangGraph loop engineering state machine
        self.workflow = self._build_graph()

    def _build_graph(self):
        workflow = StateGraph(DeepAgentHarnessState)

        workflow.add_node("prepare_tests", self.node_prepare_tests)
        workflow.add_node("generate_candidate", self.node_generate_candidate)
        workflow.add_node("validate_in_sandbox", self.node_validate_in_sandbox)
        workflow.add_node("reflect_and_repair", self.node_reflect_and_repair)

        workflow.set_entry_point("prepare_tests")
        workflow.add_edge("prepare_tests", "generate_candidate")
        workflow.add_edge("generate_candidate", "validate_in_sandbox")

        workflow.add_conditional_edges(
            "validate_in_sandbox",
            self.route_after_validation,
            {
                "success": END,
                "retry": "reflect_and_repair",
                "max_retries_exceeded": END,
            }
        )

        workflow.add_edge("reflect_and_repair", "validate_in_sandbox")
        return workflow.compile()

    # ------------------------------------------------------------------------
    # LangGraph Nodes
    # ------------------------------------------------------------------------

    def node_prepare_tests(self, state: DeepAgentHarnessState) -> Dict[str, Any]:
        """Ensures a rigorous assertion suite is present for the task."""
        if state.get("test_cases", "").strip():
            return {"test_cases": state["test_cases"]}

        task = state["task"]
        prompt = (
            f"Write a standalone Python test suite with unit assertions (`assert ...`) to validate:\n"
            f"Task: {task}\n\n"
            f"Requirements:\n"
            f"1. Include positive cases, negative cases, boundary/edge cases.\n"
            f"2. End with: print('ALL TEST CASES VALIDATED IN WINDOWS STANDALONE SANDBOX!')\n"
            f"3. Output ONLY valid Python test assertions in ```python ... ``` without conversational commentary."
        )

        resp = self.llm.invoke([
            SystemMessage(content="You are a strict QA Test Engineer. Output only Python test assertions."),
            HumanMessage(content=prompt)
        ])
        test_cases = extract_python_code(resp.content)
        return {"test_cases": test_cases}

    def node_generate_candidate(self, state: DeepAgentHarnessState) -> Dict[str, Any]:
        """Generates the initial candidate Python implementation."""
        task = state["task"]
        test_cases = state.get("test_cases", "")
        prompt = (
            f"Task: {task}\n\n"
            f"Your code will be evaluated inside an isolated Windows 11 Standalone Sandbox against this test suite:\n"
            f"```python\n{test_cases}\n```\n\n"
            f"Requirements:\n"
            f"1. Implement the requested function/class with matching signatures.\n"
            f"2. Ensure it handles edge cases and satisfies all test assertions.\n"
            f"3. Output ONLY the implementation code in ```python ... ``` without conversational text."
        )

        resp = self.llm.invoke([
            SystemMessage(content="You are an expert Python engineer. Output strictly executable code inside code fences."),
            HumanMessage(content=prompt)
        ])
        code = extract_python_code(resp.content)
        return {
            "code": code,
            "iteration": 1,
            "status": "candidate_generated",
            "history": [{
                "iteration": 1,
                "action": "generate_candidate",
                "code": code
            }]
        }

    def node_validate_in_sandbox(self, state: DeepAgentHarnessState) -> Dict[str, Any]:
        """Executes candidate code + test cases inside the Windows Job Object sandbox."""
        code = state["code"]
        test_cases = state["test_cases"]

        # Bundle code and test harness
        combined_payload = (
            f"# === Candidate Code ===\n{code}\n\n"
            f"# === Test Suite ===\n{test_cases}\n"
        )

        # Execute inside Windows 11 standalone kernel sandbox
        result = self.sandbox.run_code(
            code=combined_payload,
            filename=f"harness_iter_{state.get('iteration', 1)}.py",
            timeout=self.sandbox_timeout
        )

        result_dict = {
            "success": result.success,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "output": result.output,
            "execution_time": result.execution_time,
            "memory_peak_mb": result.memory_peak_mb,
            "timed_out": result.timed_out,
            "error_message": result.error_message
        }

        new_history = list(state.get("history", []))
        new_history.append({
            "iteration": state.get("iteration", 1),
            "action": "sandbox_validation",
            "result": result_dict
        })

        return {
            "sandbox_result": result_dict,
            "history": new_history,
            "status": "passed" if result.success else "tests_failed"
        }

    def route_after_validation(self, state: DeepAgentHarnessState) -> str:
        res = state["sandbox_result"]
        if res.get("success", False):
            return "success"
        if state["iteration"] >= state["max_iterations"]:
            return "max_retries_exceeded"
        return "retry"

    def node_reflect_and_repair(self, state: DeepAgentHarnessState) -> Dict[str, Any]:
        """Analyzes execution traceback from the sandbox and repairs the candidate code."""
        iteration = state["iteration"] + 1
        task = state["task"]
        code = state["code"]
        test_cases = state["test_cases"]
        res = state["sandbox_result"]

        error_summary = res.get("output") or res.get("stderr") or f"Exit code {res.get('exit_code')}"

        prompt = (
            f"The candidate Python code failed test validation in the Windows Standalone Sandbox.\n\n"
            f"Task: {task}\n\n"
            f"Failed Candidate Code:\n```python\n{code}\n```\n\n"
            f"Test Suite Validated Against:\n```python\n{test_cases}\n```\n\n"
            f"Sandbox Error Traceback:\n```\n{error_summary}\n```\n\n"
            f"Instructions:\n"
            f"1. Diagnose the bug or assertion failure from the traceback.\n"
            f"2. Write the corrected, complete Python implementation.\n"
            f"3. Output ONLY the repaired code enclosed in ```python ... ``` without commentary."
        )

        resp = self.llm.invoke([
            SystemMessage(content="You are an autonomous Python debugger. Repair code bugs accurately based on test failures."),
            HumanMessage(content=prompt)
        ])
        repaired_code = extract_python_code(resp.content)

        new_history = list(state.get("history", []))
        new_history.append({
            "iteration": iteration,
            "action": "reflect_and_repair",
            "code": repaired_code,
            "error_diagnosed": error_summary[:200]
        })

        return {
            "code": repaired_code,
            "iteration": iteration,
            "reflection": f"Diagnosed test failure: {error_summary[:120]}...",
            "history": new_history,
            "status": "repaired"
        }

    def run(self, task: str, test_cases: str = "") -> Dict[str, Any]:
        """Executes the full evaluation harness loop for a given task."""
        initial_state: DeepAgentHarnessState = {
            "task": task,
            "test_cases": test_cases,
            "code": "",
            "iteration": 0,
            "max_iterations": self.max_iterations,
            "sandbox_result": {},
            "reflection": "",
            "status": "starting",
            "history": []
        }
        return self.workflow.invoke(initial_state)

    def close(self):
        """Releases sandbox resources."""
        self.sandbox.close()


# ============================================================================
# Official LangChain Deep Agents Factory
# ============================================================================

def create_windows_deep_agent(
    model: Optional[Union[str, BaseChatModel]] = "gemma3:1b",
    workspace_dir: Optional[str] = None,
    max_memory_mb: int = 256,
    default_timeout: int = 20,
    system_prompt: Optional[str] = None,
):
    """
    Creates an official LangChain Deep Agent (`deepagents.create_deep_agent`)
    configured with the Standalone Windows 11 Sandbox backend.
    
    Provides:
    - Filesystem tools (`ls`, `read_file`, `write_file`, `edit_file`, `delete`, `glob`, `grep`)
    - Shell execution tool (`execute`) running in the Windows NT Job Object sandbox
    - Autonomous planning and subagent task delegation
    """
    if not DEEPAGENTS_AVAILABLE:
        raise ImportError(
            "The 'deepagents' package is required for create_windows_deep_agent. "
            "Install it via: uv pip install deepagents"
        )

    # Resolve LLM model
    if isinstance(model, str):
        from langchain_ollama import ChatOllama
        chat_model = ChatOllama(model=model, temperature=0.1)
    else:
        chat_model = model

    # Instantiate the standalone Windows sandbox backend
    sandbox_backend = WindowsStandaloneSandbox(
        workspace_dir=workspace_dir,
        max_memory_mb=max_memory_mb,
        default_timeout=default_timeout,
        cleanup_on_close=False,
    )

    prompt = system_prompt or (
        "You are an expert autonomous software engineer and deep reasoning agent. "
        "You operate in a secure, standalone Windows 11 sandbox environment. "
        "Use your filesystem tools (read_file, write_file, edit_file) and the execute tool "
        "to inspect codebases, execute scripts, run test suites, and deliver robust software."
    )

    agent = create_deep_agent(
        model=chat_model,
        backend=sandbox_backend,
        system_prompt=prompt,
    )

    return agent, sandbox_backend
