"""
Windows 11 Standalone LLM Harness Sandbox.
Zero-Docker, Zero-Podman isolation engine using Windows NT Kernel Job Objects,
Restricted Environment Sanitization, and Path-Jailed Filesystem Workspaces.

Fully implements LangChain Deep Agents `BaseSandbox` (from `deepagents.backends.sandbox`)
and provides standalone execution capabilities for LLM evaluation harnesses.
"""

from __future__ import annotations

import os
import sys
import time
import uuid
import shutil
import pathlib
import ctypes
import tempfile
import subprocess
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple, Any

from ctypes import wintypes

# Import LangChain Deep Agents BaseSandbox if installed, otherwise provide fallback base
try:
    from deepagents.backends.sandbox import (
        BaseSandbox,
        ExecuteResponse,
        FileUploadResponse,
        FileDownloadResponse,
    )
    DEEPAGENTS_AVAILABLE = True
except ImportError:
    DEEPAGENTS_AVAILABLE = False
    
    # Fallback protocol types if deepagents is not installed
    @dataclass
    class ExecuteResponse:
        output: str
        exit_code: int | None
        truncated: bool = False

    @dataclass
    class FileUploadResponse:
        path: str
        error: Optional[str] = None

    @dataclass
    class FileDownloadResponse:
        path: str
        content: Optional[bytes] = None
        error: Optional[str] = None

    class BaseSandbox:  # type: ignore
        """Fallback BaseSandbox stub when deepagents is not imported."""
        pass


# ============================================================================
# Windows Kernel Win32 API Definitions for Job Objects
# ============================================================================

kernel32 = ctypes.windll.kernel32

# Job Object Extended Limits Flags
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000
JOB_OBJECT_LIMIT_PROCESS_MEMORY = 0x0100
JOB_OBJECT_LIMIT_JOB_MEMORY = 0x0200
JOB_OBJECT_LIMIT_ACTIVE_PROCESS = 0x0008
JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION = 0x0400
JobObjectExtendedLimitInformation = 9


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_uint64),
        ("WriteOperationCount", ctypes.c_uint64),
        ("OtherOperationCount", ctypes.c_uint64),
        ("ReadTransferCount", ctypes.c_uint64),
        ("WriteTransferCount", ctypes.c_uint64),
        ("OtherTransferCount", ctypes.c_uint64),
    ]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_int64),
        ("PerJobUserTimeLimit", ctypes.c_int64),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


@dataclass
class SandboxExecutionResult:
    """Detailed result container for standalone harness execution."""
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    output: str
    execution_time: float
    memory_peak_mb: float = 0.0
    timed_out: bool = False
    truncated: bool = False
    error_message: Optional[str] = None
    workspace_dir: Optional[str] = None

    def summary(self) -> str:
        status = "PASSED" if self.success else ("TIMED OUT" if self.timed_out else "FAILED")
        return (
            f"[{status}] Exit Code: {self.exit_code} | Duration: {self.execution_time:.3f}s | "
            f"Peak RAM: {self.memory_peak_mb:.1f}MB\n"
            f"Output:\n{self.output.strip()}"
        )


class WindowsStandaloneSandbox(BaseSandbox):
    """
    Standalone Windows 11 Code Execution Sandbox for LangChain Deep Agents.
    
    Security & Isolation Guarantees:
    1. Kernel Job Object Enforcement:
       - Memory limits (Process & Job caps) enforced by Windows NT kernel.
       - Max active child process limit (mitigates fork-bombs).
       - JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE: Guarantees no orphaned background processes.
       - Hard timeout termination via kernel TerminateJobObject.
    2. Filesystem Path Jailing:
       - All file operations are locked to an isolated workspace directory.
       - Directory traversal ('..', system drives) is blocked with path containment checks.
    3. Environment Sanitization:
       - Host secrets (API keys, cloud tokens, user profile paths) are stripped.
       - %TEMP% and %TMP% are redirected inside the isolated sandbox workspace.
    4. BaseSandbox Compatibility:
       - Directly implements LangChain Deep Agents `BaseSandbox` protocol.
       - Drop-in backend for `deepagents.create_deep_agent(backend=...)`.
    """

    def __init__(
        self,
        workspace_dir: Optional[str] = None,
        *,
        sandbox_id: Optional[str] = None,
        max_memory_mb: int = 256,
        max_job_memory_mb: int = 512,
        max_active_processes: int = 5,
        default_timeout: int = 20,
        max_output_bytes: int = 100_000,
        cleanup_on_close: bool = True,
        python_executable: Optional[str] = None
    ):
        self._sandbox_id = sandbox_id or f"win-sbx-{uuid.uuid4().hex[:8]}"
        self.max_memory_mb = max_memory_mb
        self.max_job_memory_mb = max_job_memory_mb
        self.max_active_processes = max_active_processes
        self.default_timeout = default_timeout
        self.max_output_bytes = max_output_bytes
        self.cleanup_on_close = cleanup_on_close
        self.python_executable = python_executable or sys.executable

        # Set up isolated workspace root
        if workspace_dir:
            self.root_path = pathlib.Path(workspace_dir).resolve()
            self.root_path.mkdir(parents=True, exist_ok=True)
            self._is_temp_dir = False
        else:
            self._temp_dir_obj = tempfile.TemporaryDirectory(prefix=f"win_sandbox_{self._sandbox_id}_")
            self.root_path = pathlib.Path(self._temp_dir_obj.name).resolve()
            self._is_temp_dir = True

        # Create subdirectories for execution temp files
        (self.root_path / "temp").mkdir(exist_ok=True)
        (self.root_path / "src").mkdir(exist_ok=True)

        # Initialize Windows Job Object
        self._job_handle = self._create_configured_job()

    @property
    def id(self) -> str:
        """Stable unique identifier for LangChain Deep Agents."""
        return self._sandbox_id

    @property
    def workspace(self) -> str:
        """Absolute string path of the sandbox workspace directory."""
        return str(self.root_path)

    # ------------------------------------------------------------------------
    # Windows Kernel Job Object Management
    # ------------------------------------------------------------------------

    def _create_configured_job(self) -> wintypes.HANDLE:
        """Creates and configures a Windows NT Job Object with resource limits."""
        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            raise OSError(f"Failed to create Windows Job Object. Error code: {ctypes.GetLastError()}")

        limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        limits.BasicLimitInformation.LimitFlags = (
            JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE |
            JOB_OBJECT_LIMIT_PROCESS_MEMORY |
            JOB_OBJECT_LIMIT_JOB_MEMORY |
            JOB_OBJECT_LIMIT_ACTIVE_PROCESS |
            JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION
        )
        limits.BasicLimitInformation.ActiveProcessLimit = self.max_active_processes
        limits.ProcessMemoryLimit = self.max_memory_mb * 1024 * 1024
        limits.JobMemoryLimit = self.max_job_memory_mb * 1024 * 1024

        success = kernel32.SetInformationJobObject(
            job,
            JobObjectExtendedLimitInformation,
            ctypes.byref(limits),
            ctypes.sizeof(limits),
        )
        if not success:
            kernel32.CloseHandle(job)
            raise OSError(f"Failed to set Windows Job Object limits. Error code: {ctypes.GetLastError()}")

        return job

    def _get_job_peak_memory_mb(self) -> float:
        """Queries the kernel for peak memory consumed across all processes in the job."""
        if not self._job_handle:
            return 0.0
        info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        ret_len = wintypes.DWORD()
        res = kernel32.QueryInformationJobObject(
            self._job_handle,
            JobObjectExtendedLimitInformation,
            ctypes.byref(info),
            ctypes.sizeof(info),
            ctypes.byref(ret_len),
        )
        if res:
            return round(info.PeakJobMemoryUsed / (1024 * 1024), 2)
        return 0.0

    # ------------------------------------------------------------------------
    # Filesystem Path Jailing
    # ------------------------------------------------------------------------

    def resolve_safe_path(self, relative_or_absolute: str) -> pathlib.Path:
        """
        Resolves a path ensuring it stays strictly inside the sandbox workspace.
        Prevents directory traversal attacks ('..', 'C:\\Windows', etc.).
        """
        clean = relative_or_absolute.replace("\\", "/").strip()
        # Strip leading slashes to prevent root-escape interpretation
        clean = clean.lstrip("/")

        target = (self.root_path / clean).resolve()

        # Strict containment check
        try:
            target.relative_to(self.root_path)
        except ValueError:
            raise PermissionError(
                f"Sandbox Security Violation: Path '{relative_or_absolute}' escapes sandbox root '{self.root_path}'"
            )

        return target

    # ------------------------------------------------------------------------
    # Environment Sanitization
    # ------------------------------------------------------------------------

    def _build_sanitized_env(self) -> Dict[str, str]:
        """
        Constructs a minimal, secure environment for child execution on Windows 11.
        Strips host API keys, secret credentials, and user data.
        """
        env = {
            "SYSTEMROOT": os.environ.get("SYSTEMROOT", "C:\\Windows"),
            "WINDIR": os.environ.get("WINDIR", "C:\\Windows"),
            "COMSPEC": os.environ.get("COMSPEC", "C:\\Windows\\system32\\cmd.exe"),
            "PATHEXT": os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH"),
            # Redirect temp directories strictly inside sandbox
            "TEMP": str(self.root_path / "temp"),
            "TMP": str(self.root_path / "temp"),
            "USERPROFILE": str(self.root_path),
            "PYTHONUNBUFFERED": "1",
            "PYTHONIOENCODING": "utf-8",
        }

        # Include Python bin / virtualenv directory in PATH
        py_dir = str(pathlib.Path(self.python_executable).parent)
        system32 = "C:\\Windows\\system32"
        windows_dir = "C:\\Windows"
        env["PATH"] = f"{py_dir};{system32};{windows_dir}"

        return env

    # ------------------------------------------------------------------------
    # Core BaseSandbox Methods (LangChain Deep Agents Protocol)
    # ------------------------------------------------------------------------

    def execute(self, command: str, *, timeout: Optional[int] = None) -> ExecuteResponse:
        """
        Executes a shell command inside the Windows 11 Job Object sandbox.
        Automatically adapts 'python3' calls to the local Python runtime.
        """
        eff_timeout = timeout or self.default_timeout

        # Translate 'python3' or 'python' to explicit safe executable path
        adapted_command = command
        if adapted_command.startswith("python3 "):
            adapted_command = f'"{self.python_executable}" ' + adapted_command[8:]
        elif adapted_command.startswith("python "):
            adapted_command = f'"{self.python_executable}" ' + adapted_command[7:]

        sanitized_env = self._build_sanitized_env()

        # Execute under cmd.exe within workspace directory
        try:
            proc = subprocess.Popen(
                adapted_command,
                shell=True,
                cwd=str(self.root_path),
                env=sanitized_env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )

            # Assign process to Windows NT Job Object
            if self._job_handle:
                kernel32.AssignProcessToJobObject(self._job_handle, int(proc._handle))

            stdout, _ = proc.communicate(timeout=eff_timeout)
            exit_code = proc.returncode

        except subprocess.TimeoutExpired:
            # Terminate the entire job object to kill the hung process and all spawned subprocesses
            if self._job_handle:
                kernel32.TerminateJobObject(self._job_handle, 124)
            proc.kill()
            stdout, _ = proc.communicate()
            exit_code = 124
            stdout += f"\n[SANDBOX TIMEOUT: Execution exceeded limit of {eff_timeout} seconds]"

        except Exception as e:
            return ExecuteResponse(
                output=f"Execution error: {str(e)}",
                exit_code=-1,
                truncated=False,
            )

        # Truncate output if necessary
        truncated = False
        raw_output = stdout or ""
        if len(raw_output.encode("utf-8", errors="replace")) > self.max_output_bytes:
            raw_output = raw_output[: self.max_output_bytes] + "\n...[OUTPUT TRUNCATED BY SANDBOX]"
            truncated = True

        return ExecuteResponse(
            output=raw_output,
            exit_code=exit_code,
            truncated=truncated,
        )

    def upload_files(self, files: List[Tuple[str, bytes]]) -> List[FileUploadResponse]:
        """
        Seeds / writes files into the sandbox workspace.
        Enforces path jailing to prevent path traversal.
        """
        responses: List[FileUploadResponse] = []
        for path_str, content in files:
            try:
                dest = self.resolve_safe_path(path_str)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(content)
                responses.append(FileUploadResponse(path=path_str, error=None))
            except Exception as e:
                responses.append(FileUploadResponse(path=path_str, error=str(e)))
        return responses

    def download_files(self, paths: List[str]) -> List[FileDownloadResponse]:
        """
        Reads files out of the sandbox workspace.
        Enforces path jailing to prevent unauthorized file exfiltration.
        """
        responses: List[FileDownloadResponse] = []
        for path_str in paths:
            try:
                source = self.resolve_safe_path(path_str)
                if not source.exists() or not source.is_file():
                    responses.append(FileDownloadResponse(path=path_str, content=None, error="file_not_found"))
                else:
                    responses.append(FileDownloadResponse(path=path_str, content=source.read_bytes(), error=None))
            except Exception as e:
                responses.append(FileDownloadResponse(path=path_str, content=None, error=str(e)))
        return responses

    # ------------------------------------------------------------------------
    # Standalone Code Execution Engine (For LLM Harness Evaluation)
    # ------------------------------------------------------------------------

    def run_code(
        self,
        code: str,
        *,
        language: str = "python",
        filename: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> SandboxExecutionResult:
        """
        Executes a Python code snippet inside the sandbox and returns detailed harness metrics.
        """
        start_time = time.time()
        timeout = timeout or self.default_timeout

        if language.lower() != "python":
            return SandboxExecutionResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr=f"Language '{language}' not supported in native standalone mode.",
                output=f"Unsupported language: {language}",
                execution_time=0.0,
            )

        script_name = filename or f"eval_{uuid.uuid4().hex[:6]}.py"
        script_path = self.resolve_safe_path(f"src/{script_name}")
        script_path.write_text(code, encoding="utf-8")

        # Execute script via the Job Object sandbox
        cmd = f'"{self.python_executable}" "src/{script_name}"'
        resp = self.execute(cmd, timeout=timeout)
        duration = time.time() - start_time
        peak_mb = self._get_job_peak_memory_mb()

        timed_out = resp.exit_code == 124 or "SANDBOX TIMEOUT" in resp.output
        success = resp.exit_code == 0

        stdout = resp.output if success else ""
        stderr = resp.output if not success else ""

        return SandboxExecutionResult(
            success=success,
            exit_code=resp.exit_code if resp.exit_code is not None else -1,
            stdout=stdout,
            stderr=stderr,
            output=resp.output,
            execution_time=round(duration, 3),
            memory_peak_mb=peak_mb,
            timed_out=timed_out,
            truncated=resp.truncated,
            workspace_dir=str(self.root_path),
        )

    # ------------------------------------------------------------------------
    # Context Manager & Lifecycle Cleanup
    # ------------------------------------------------------------------------

    def close(self) -> None:
        """Closes the Windows Job Object handle and optionally cleans up the workspace."""
        if self._job_handle:
            try:
                kernel32.CloseHandle(self._job_handle)
            except Exception:
                pass
            self._job_handle = None

        if self.cleanup_on_close and hasattr(self, "_temp_dir_obj"):
            try:
                self._temp_dir_obj.cleanup()
            except Exception:
                pass

    def __enter__(self) -> "WindowsStandaloneSandbox":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self) -> None:
        self.close()
